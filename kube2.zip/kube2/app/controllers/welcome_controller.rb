class WelcomeController < ApplicationController
  def index
  end
  def page
  end
end
